
## ASSIGNMENT 3:

```bash
cd C:\Users\YASH\Desktop\OS assignment\OS_assignment3\code
```

### task 1:
```bash
python3 code1.py
```

### task 2:
```bash
python3 code2.py
```
### task 3:
```bash
python3 code3.py
```
### task 4:
```bash
python3 code4.py
```
### task 5:
```bash
python3 code5.py
```
***
