# Operating System Lab Assignment

**Author:** Yash Malik  
**Roll no.:** 2301010006
**Course:** ENCS351 - Operating Systems  
**Program:** B.Tech CSE Core 

OS-Assignments/
  README.md              
  assignment_1/
    process_management.py
    output.txt
    README.md            
  assignment_2/
    system_startup.py
    process_log.txt
    README.md            
  assignment_3
    README.md
    code/
    output/
  assignment_4/
    README.md
    code/
    output/
