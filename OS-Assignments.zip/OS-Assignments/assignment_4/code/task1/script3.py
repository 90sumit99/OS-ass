print("Script 3 is running!")
