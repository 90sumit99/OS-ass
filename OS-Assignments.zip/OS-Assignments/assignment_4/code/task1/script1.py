print("This is Script 1")

