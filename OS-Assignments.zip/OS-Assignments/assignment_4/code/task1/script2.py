print("This is Script 2")

