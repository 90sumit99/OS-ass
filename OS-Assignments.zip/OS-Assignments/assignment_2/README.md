# Assignment 2

This folder contains my Operating Systems lab assignment 2.

## Files
- Code and related outputs for assignment 2.

## Notes
- Add your own description of the aim, logic, and how to run the code here.
