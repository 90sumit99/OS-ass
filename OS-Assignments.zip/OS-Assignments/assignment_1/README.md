# Assignment 1

This folder contains my Operating Systems lab assignment 1.

## Files
- Code and related outputs for assignment 1.

## Notes
- Add your own description of the aim, logic, and how to run the code here.
